package com.phazejeff.mcgpt;

import java.util.List;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.text.Text;

public class Build {

    public static void build(JsonObject build, int startX, int startY, int startZ, ServerWorld world) {
        List<JsonElement> blocks = build.get("blocks").getAsJsonArray().asList();

        for (JsonElement b : blocks) {
            JsonObject block = b.getAsJsonObject();
            int blockX = block.get("x").getAsInt();
            int blockY = block.get("y").getAsInt();
            int blockZ = block.get("z").getAsInt();
            String blockType = block.get("type").getAsString();

            boolean fill = false;
            try {
                fill = block.get("fill").getAsBoolean();
            } catch (NullPointerException e) {
                fill = false;
            }

            if (fill) {
                int endBlockX = block.get("endX").getAsInt();
                int endBlockY = block.get("endY").getAsInt();
                int endBlockZ = block.get("endZ").getAsInt();

                int lengthX = Math.abs(blockX - endBlockX);
                int lengthY = Math.abs(blockY - endBlockY);
                int lengthZ = Math.abs(blockZ - endBlockZ);

                System.out.println("Using fill: start=(" + (startX + blockX) + ", " + (startY + blockY) + ", " + (startZ + blockZ) + "), lengths=(" + lengthX + ", " + lengthY + ", " + lengthZ + "), type=" + blockType);

                fillArea(
                    startX + blockX, startY + blockY, startZ + blockZ, 
                    lengthX, lengthY, lengthZ, 
                    blockType, world
                );
            } else {
                System.out.println("Creating block: pos=(" + (startX + blockX) + ", " + (startY + blockY) + ", " + (startZ + blockZ) + "), type=" + blockType);

                placeBlock(
                    startX + blockX, startY + blockY, startZ + blockZ, 
                    blockType, world
                );
            } 
        }
    }

    private static void fillArea(
        int startX, int startY, int startZ, 
        int lengthX, int lengthY, int lengthZ, 
        String blockType, ServerWorld world
    ) {
        for (int x = 0; x <= lengthX; x++) {
            for (int y = 0; y <= lengthY; y++) {
                for (int z = 0; z <= lengthZ; z++) {
                    placeBlock(
                        startX + x, startY + y, startZ + z, 
                        blockType, world
                    );
                }
            }
        }
    }

    private static void placeBlock(int x, int y, int z, String blockType, ServerWorld world) {
        BlockPos pos = new BlockPos(x, y, z);
        BlockState blockState = getBlockState(blockType);
        world.setBlockState(pos, blockState);
        System.out.println("Placed block at: " + x + ", " + y + ", " + z + " of type " + blockType);
    }

    private static BlockState getBlockState(String blockType) {
        Identifier id = Identifier.tryParse(blockType);
        Block blockMC = Registries.BLOCK.get(id);
        if (blockMC == null) {
            System.out.println("Couldn't find block for " + blockType + ". Defaulting to stone.");
            return Blocks.STONE.getDefaultState();
        }
        return blockMC.getDefaultState();
    }

    public static BlockPos getTargettedBlock(ServerCommandSource source) {
        HitResult blockHit = source.getPlayer().raycast(20.0D, 0.0f, true);
        if (blockHit.getType() != HitResult.Type.BLOCK) {
            source.sendError(Text.of("Must be looking at a block!"));
            return new BlockPos(0, 0, 0);
        }

        BlockPos blockPos = ((BlockHitResult) blockHit).getBlockPos();
        return blockPos;
    }

    public static BuildItem makeBuildItem(List<String> messages, BlockPos zeroLocation) {
        Pos pos = new Pos(zeroLocation.getX(), zeroLocation.getY(), zeroLocation.getZ());
        Chat chat = new Chat(pos, messages);

        Identifier id = new Identifier("mcgpt", "build");
        BuildItem buildItem = (BuildItem) Registries.ITEM.get(id);

        buildItem.setChat(chat);

        return buildItem;
    }

    public static void buildFromSTL(List<float[]> vertices, int startX, int startY, int startZ, ServerWorld world, float scale) {
        // Determine the bounding box
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, minZ = Float.MAX_VALUE;
        float maxX = Float.MIN_VALUE, maxY = Float.MIN_VALUE, maxZ = Float.MIN_VALUE;

        for (float[] vertex : vertices) {
            if (vertex[0] < minX) minX = vertex[0];
            if (vertex[1] < minY) minY = vertex[1];
            if (vertex[2] < minZ) minZ = vertex[2];

            if (vertex[0] > maxX) maxX = vertex[0];
            if (vertex[1] > maxY) maxY = vertex[1];
            if (vertex[2] > maxZ) maxZ = vertex[2];
        }

        System.out.println("Model bounding box: (" + minX + ", " + minY + ", " + minZ + ") to (" + maxX + ", " + maxY + ", " + maxZ + ")");

        // Calculate dimensions
        int width = (int) Math.ceil((maxX - minX) * scale);
        int height = (int) Math.ceil((maxY - minY) * scale);
        int depth = (int) Math.ceil((maxZ - minZ) * scale);

        System.out.println("Model dimensions: width=" + width + ", height=" + height + ", depth=" + depth);

        if (width * height * depth > Integer.MAX_VALUE) {
            System.out.println("Model is too large to fit in memory. Adjust scale or model size.");
            return;
        }

        // Rotate the model to stand upright
        boolean[][][] voxelGrid = new boolean[width][height][depth];

        for (float[] vertex : vertices) {
            int x = Math.round((vertex[0] - minX) * scale);
            int y = Math.round((vertex[2] - minZ) * scale); // Swapping Y and Z to rotate
            int z = Math.round((vertex[1] - minY) * scale); // Swapping Y and Z to rotate

            if (x >= 0 && x < width && y >= 0 && y < height && z >= 0 && z < depth) {
                voxelGrid[x][y][z] = true;
            } else {
                System.out.println("Skipping vertex out of bounds: (" + x + ", " + y + ", " + z + ")");
            }
        }

        for (int x = 0; x < voxelGrid.length; x++) {
            for (int y = 0; y < voxelGrid[x].length; y++) {
                for (int z = 0; z < voxelGrid[x][y].length; z++) {
                    if (voxelGrid[x][y][z]) {
                        placeBlock(startX + x, startY + y, startZ + z, "minecraft:stone", world);
                    }
                }
            }
        }
    }
}
