package com.phazejeff.mcgpt;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import static net.minecraft.server.command.CommandManager.*;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;

public class MinecraftGPT implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("minecraftgpt");

    public static final Item BUILD_ITEM = new BuildItem(new FabricItemSettings());

    public static String openai_key = "sk-proj-uHiETDPVtRRsT4Y8581mT3BlbkFJgku0tx5PJuLEDfUvYrIC";
    public static boolean gpt4 = false;
    public static boolean gpt35turbo = false;        
    public static boolean gpt4o = true;
    
    @Override
    public void onInitialize() {
        LOGGER.info("Starting McGPT!");

        Registry.register(Registries.ITEM, new Identifier("mcgpt", "build"), BUILD_ITEM);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            literal("gpt4")
            .executes(context -> {
                gpt4 = true;
                gpt4o = false;
                gpt35turbo = false;
                context.getSource().sendMessage(Text.of("GPT4 now set to " + gpt4));
                return 0;
            })
        ));
        
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            literal("gpt4o")
            .executes(context -> {
                gpt4 = false;
                gpt4o = true;
                gpt35turbo = false;
                context.getSource().sendMessage(Text.of("GPT4o now set to " + gpt4o));
                return 0;
            })
        ));
        
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            literal("gpt35turbo")
            .executes(context -> {
                gpt4 = false;
                gpt4o = false;
                gpt35turbo = true;
                context.getSource().sendMessage(Text.of("GPT35turbo now set to " + gpt35turbo));
                return 0;
            })
        ));
        
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            literal("setkey")
            .then(argument("key", StringArgumentType.greedyString())
                .executes(context -> {
                    openai_key = StringArgumentType.getString(context, "key");

                    context.getSource().sendMessage(Text.of("Open AI key set. Use /build to get started."));
                    return 1;
                })
            )
        ));

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            literal("build")
            .requires(source -> source.isExecutedByPlayer())
            .then(argument("prompt", StringArgumentType.greedyString())
                .executes(context -> {
                    if (openai_key == null) {
                        context.getSource().sendMessage(Text.of("Please set your openai key with /setkey"));
                        return 0;
                    }

                    try {
                    Long startTime = System.currentTimeMillis();
                    
                    ServerCommandSource source = context.getSource();
                    String prompt = StringArgumentType.getString(context, "prompt");

                    source.sendMessage(Text.of("Building " + prompt + "..."));

                    new Thread(() -> {
                        List<String> messages = new ArrayList<String>();
                        messages.add("Build " + prompt);

                        BlockPos blockPos = Build.getTargettedBlock(source);
                        JsonObject build = OpenAI.promptBuild(prompt);
                        messages.add(build.toString());

                        ServerWorld world = source.getWorld();

                        Build.build(build, blockPos.getX(), blockPos.getY(), blockPos.getZ(), world);
                        
                        
                        BuildItem buildItem = Build.makeBuildItem(messages, blockPos);
                        ItemStack itemStack = buildItem.getItemStack(messages, blockPos.getX(), blockPos.getY(), blockPos.getZ());

                        itemStack.setCustomName(Text.of(prompt));

                        source.getPlayer().giveItemStack(itemStack);
                        long endTime = System.currentTimeMillis();
                        source.sendMessage(Text.of("Done in " + (float) ((endTime - startTime) / 1000.0f) + " seconds"));
                    }).start();

                    } catch (Exception e) {
                        e.printStackTrace();
                        context.getSource().sendMessage(Text.of(e.toString()));
                    }
                    
                    return 1;
                })
            )
        ));
        
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            literal("edit")
            .requires(source -> source.isExecutedByPlayer())
            .then(argument("prompt", StringArgumentType.greedyString())
                .executes(context -> {
                    if (openai_key == null) {
                        context.getSource().sendMessage(Text.of("Please set your openai key with /setkey"));
                        return 0;
                    }

                    try {
                    Long startTime = System.currentTimeMillis();

                    ServerCommandSource source = context.getSource();
                    String prompt = StringArgumentType.getString(context, "prompt");
                    source.sendMessage(Text.of("Edit: " + prompt + "..."));

                    ItemStack buildItemStack = source.getPlayer().getMainHandStack();

                    if (!buildItemStack.getItem().equals(BUILD_ITEM)) {
                        source.sendMessage(Text.of("Please be holding a build item (given by /build) to use this."));
                        return 1;
                    }

                    BuildItem buildItem = (BuildItem) buildItemStack.getItem();
                    NbtCompound nbt = buildItemStack.getNbt();
                    Text name = buildItemStack.getName();

                    int x = nbt.getInt("x");
                    int y = nbt.getInt("y");
                    int z = nbt.getInt("z");

                    List<String> messages = new ArrayList<String>();

                    for (int i = 0; i < nbt.getInt("size"); i++) {
                        String m = nbt.getString(String.valueOf(i));
                        messages.add(m);
                    }
                    messages.add(prompt);

                    new Thread(() -> {
                        JsonObject edit = OpenAI.promptEdit(messages);
                        Build.build(edit, x, y, z, source.getWorld());

                        messages.add(edit.toString());
                        ItemStack newBuildItemStack = buildItem.updateItemStack(buildItemStack.getNbt(), messages);
                        buildItemStack.setNbt(newBuildItemStack.getNbt());
                        buildItemStack.setCustomName(name);

                        long endTime = System.currentTimeMillis();
                        source.sendMessage(Text.of("Done in " + (float) ((endTime - startTime) / 1000) + " seconds"));
                    }).start();
                    
                    } catch (Exception e) {
                        e.printStackTrace();
                        context.getSource().sendMessage(Text.of(e.toString()));
                    }
                    return 1;
                })
            )
        ));

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            literal("buildstl")
            .requires(source -> source.isExecutedByPlayer())
            .then(argument("filename", StringArgumentType.string())
                .then(argument("scale", FloatArgumentType.floatArg())
                    .executes(context -> {
                        ServerCommandSource source = context.getSource();
                        String filename = StringArgumentType.getString(context, "filename");
                        float scale = FloatArgumentType.getFloat(context, "scale");

                        source.sendMessage(Text.of("Building from STL file: " + filename + " with scale: " + scale));

                        new Thread(() -> {
                            try {
                                Long startTime = System.currentTimeMillis();
                                
                                BlockPos blockPos = Build.getTargettedBlock(source);
                                ServerWorld world = source.getWorld();
                                
                                InputStream stlInputStream = getClass().getClassLoader().getResourceAsStream("assets/minecraftgpt/" + filename);
                                if (stlInputStream == null) {
                                    source.sendMessage(Text.of("Could not find the STL file: " + filename));
                                    return;
                                }

                                List<float[]> vertices = SimpleSTLParser.parseSTLFile(new InputStreamReader(stlInputStream));
                                if (vertices.isEmpty()) {
                                    source.sendMessage(Text.of("No vertices found in the STL file: " + filename));
                                    return;
                                }
                                source.sendMessage(Text.of("Parsed " + vertices.size() + " vertices from STL file."));

                                Build.buildFromSTL(vertices, blockPos.getX(), blockPos.getY(), blockPos.getZ(), world, scale);

                                long endTime = System.currentTimeMillis();
                                source.sendMessage(Text.of("STL model built in " + (float) ((endTime - startTime) / 1000.0f) + " seconds"));
                            } catch (Exception e) {
                                e.printStackTrace();
                                context.getSource().sendMessage(Text.of(e.toString()));
                            }
                        }).start();

                        return 1;
                    })
                )
            )
        ));
    }
}
