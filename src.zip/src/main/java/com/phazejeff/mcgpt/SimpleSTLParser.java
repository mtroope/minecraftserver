package com.phazejeff.mcgpt;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class SimpleSTLParser {

    public static List<float[]> parseSTLFile(InputStreamReader reader) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(reader);
        List<float[]> vertices = new ArrayList<>();
        String line;
        int lineNumber = 0;

        while ((line = bufferedReader.readLine()) != null) {
            lineNumber++;
            line = line.trim();
            if (line.startsWith("vertex")) {
                String[] parts = line.split("\\s+");
                if (parts.length == 4) {
                    try {
                        float x = Float.parseFloat(parts[1]);
                        float y = Float.parseFloat(parts[2]);
                        float z = Float.parseFloat(parts[3]);
                        vertices.add(new float[]{x, y, z});
                    } catch (NumberFormatException e) {
                        System.err.println("Error parsing vertex on line " + lineNumber + ": " + line);
                    }
                } else {
                    System.err.println("Invalid vertex format on line " + lineNumber + ": " + line);
                }
            }
        }

        System.out.println("Finished parsing STL file. Total vertices: " + vertices.size());
        return vertices;
    }
}
